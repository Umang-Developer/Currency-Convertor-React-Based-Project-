import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const Converter = () => {
  const [amount, setAmount] = useState('');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');
  const [result, setResult] = useState(null);
  const [currencies, setCurrencies] = useState([]);
  const [rateHistory, setRateHistory] = useState([]);
  const [rateTrend, setRateTrend] = useState('');
  const [arrowDirection, setArrowDirection] = useState('');
  const [exchangeRate, setExchangeRate] = useState(null);

  // Fetch available currencies on mount
  useEffect(() => {
    const fetchCurrencies = async () => {
      try {
        const response = await axios.get('https://api.exchangerate-api.com/v4/latest/USD');
        setCurrencies(Object.keys(response.data.rates));
      } catch (error) {
        console.error('Error fetching currency data:', error);
      }
    };

    fetchCurrencies();
  }, []);

  // Handle conversion logic
  const handleConvert = async () => {
    if (!amount || isNaN(amount)) {
      alert('Please enter a valid amount.');
      return;
    }

    try {
      const response = await axios.get(`https://api.exchangerate-api.com/v4/latest/${fromCurrency}`);
      const rate = response.data.rates[toCurrency];
      setExchangeRate(rate); // Store the current exchange rate
      setResult((amount * rate).toFixed(2));

      // Update rate history and track rate trend
      setRateTrend(getRateTrend(rate));
      setArrowDirection(getArrowDirection(rate));
      
      // Append the new rate to history and limit length
      setRateHistory((prev) => {
        const newHistory = [...prev, { x: new Date().toLocaleString(), y: rate }];
        if (newHistory.length > 10) newHistory.shift(); // Keep history length under 10
        return newHistory;
      });
    } catch (error) {
      console.error('Error fetching exchange rate:', error);
      alert('Error converting currency.');
    }
  };

  // Function to determine the rate trend
  const getRateTrend = (currentRate) => {
    if (rateHistory.length === 0) {
      return '';
    }
    const previousRate = rateHistory[rateHistory.length - 1].y;

    if (currentRate > previousRate) return 'Increasing';
    if (currentRate < previousRate) return 'Decreasing';
    return 'Constant';
  };

  // Function to determine the arrow direction
  const getArrowDirection = (currentRate) => {
    if (rateHistory.length === 0) return '';
    const previousRate = rateHistory[rateHistory.length - 1].y;

    if (currentRate > previousRate) return '↑';
    if (currentRate < previousRate) return '↓';
    return '→';
  };

  // Prepare data for the chart
  const chartData = {
    datasets: [
      {
        label: `Exchange Rate (${fromCurrency} to ${toCurrency})`,
        data: rateHistory,
        borderColor: 'rgba(75, 192, 192, 1)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        fill: true,
        tension: 0.1,
      },
    ],
  };

  return (
    <div className="converter">
      <h1>Currency Converter</h1>
      <div className="conversion-form">
        <input
          type="number"
          placeholder="Enter amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <div className="currency-select">
          <select value={fromCurrency} onChange={(e) => setFromCurrency(e.target.value)}>
            {currencies.map((currency) => (
              <option key={currency} value={currency}>{currency}</option>
            ))}
          </select>
          <select value={toCurrency} onChange={(e) => setToCurrency(e.target.value)}>
            {currencies.map((currency) => (
              <option key={currency} value={currency}>{currency}</option>
            ))}
          </select>
        </div>
        <button onClick={handleConvert}>Convert</button>
      </div>

      {exchangeRate && (
        <h3>
          Exchange Rate: 1 {fromCurrency} = {exchangeRate.toFixed(2)} {toCurrency}
        </h3>
      )}

      {result && <h2>{amount} {fromCurrency} = {result} {toCurrency}</h2>}

      {rateTrend && (
        <div className={`rate-trend ${rateTrend.toLowerCase()}`}>
          <h3>
            Rate Trend: {rateTrend} {arrowDirection}
          </h3>
        </div>
      )}

      {rateHistory.length > 0 && (
        <div className="rate-chart">
          <h3>Rate Trend Chart</h3>
          <Line data={chartData} />
        </div>
      )}
    </div>
  );
};

export default Converter;
